class Tweet(object):

    def __init__(self, content, polarity):
        self.content = content
        self.polarity = polarity